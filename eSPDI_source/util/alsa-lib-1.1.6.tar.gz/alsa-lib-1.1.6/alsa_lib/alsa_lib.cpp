#include "alsa_lib.h"


Alsa_lib::Alsa_lib()
{
}
