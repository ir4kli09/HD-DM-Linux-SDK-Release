#ifndef ALSA_LIB_H
#define ALSA_LIB_H

#include "alsa_lib_global.h"

class ALSA_LIBSHARED_EXPORT Alsa_lib
{

public:
    Alsa_lib();
};

#endif // ALSA_LIB_H
