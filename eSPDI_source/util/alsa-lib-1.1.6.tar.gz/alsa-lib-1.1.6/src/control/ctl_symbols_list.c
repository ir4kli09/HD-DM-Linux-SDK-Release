&_snd_module_control_shm,
&_snd_module_control_ext,
